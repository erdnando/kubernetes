---
title: MySQL Operator
linktitle: Getting started with MySQL operator
description: The MySQL Kubernetes Operator manages all the necessary resources for deploying and managing a highly available MySQL cluster.
categories: [mysql operator]
keywords: [mysql operator, cluster, getting-started]
toc: false
related: false
layout: documentation-home
---

# MySQL Operator

The MySQL Kubernetes Operator manages all the necessary resources for deploying and managing a highly available MySQL cluster.
