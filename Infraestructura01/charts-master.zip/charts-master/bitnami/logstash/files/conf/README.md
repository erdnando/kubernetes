Place your Logstash configuration files here. This will not be used in case the value *existingConfiguration* is used.

More information [here](https://github.com/bitnami/bitnami-docker-logstash#configuration)
