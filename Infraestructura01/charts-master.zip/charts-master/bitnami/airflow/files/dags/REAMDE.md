You can copy here your DAGs files so they are mounted at "/opt/bitnami/airflow/dags" inside the docker image.
