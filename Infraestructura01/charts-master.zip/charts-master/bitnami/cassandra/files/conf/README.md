Place your Cassandra configuration files here. This will override the values set in any configuration environment variable. This will not be used in case the value *existingConfiguration* is used.

More information [here](https://github.com/bitnami/bitnami-docker-cassandra#configuration)
