You can copy here your custom `.sh` or `.cql` file so they are executed during the first boot of the image.

More info in the [bitnami-docker-cassandra](https://github.com/bitnami/bitnami-docker-cassandra#initializing-a-new-instance) repository.
