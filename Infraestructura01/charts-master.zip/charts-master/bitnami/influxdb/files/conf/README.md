Place your InfluxDB and InfluxDB Relay configuration files here. These will not be used in case the values *existingConfiguration*, *relay.existingConfiguration* are used.

More information can be found in the links below:

- [InfluxDB Configuration File](https://github.com/bitnami/bitnami-docker-influxdb#configuration-file)
- [InfluxDB Relay Configuration File](https://github.com/bitnami/bitnami-docker-influxdb-relay#configuration)
